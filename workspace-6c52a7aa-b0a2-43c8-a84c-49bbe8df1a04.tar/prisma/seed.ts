import { db } from '@/lib/db'

const sampleSnippets = [
  {
    title: 'Unvalidated User Input Handler',
    language: 'JavaScript',
    code: `function processUserInput(input) {
  const data = eval(input);
  return data;
}

app.post('/api/data', (req, res) => {
  const result = processUserInput(req.body.data);
  res.json({ result });
});`,
    expectedBehavior: 'Should safely process user input and return parsed data',
    knownIssue: 'Uses eval() which is dangerous'
  },
  {
    title: 'SQL Query Builder',
    language: 'Python',
    code: `def get_user(user_id):
    query = f"SELECT * FROM users WHERE id = {user_id}"
    cursor.execute(query)
    return cursor.fetchone()`,
    expectedBehavior: 'Should fetch a user by ID from the database',
    knownIssue: 'Vulnerable to SQL injection'
  },
  {
    title: 'Array Sort Algorithm',
    language: 'JavaScript',
    code: `function sortNumbers(arr) {
  return arr.sort();
}

console.log(sortNumbers([10, 2, 30, 1, 20]));`,
    expectedBehavior: 'Should sort numbers in ascending order',
    knownIssue: 'sort() without comparator sorts lexicographically'
  },
  {
    title: 'File Read Handler',
    language: 'Python',
    code: `def read_file(filename):
    with open(filename, 'r') as f:
        data = f.read()
    return data

content = read_file(user_provided_path)`,
    expectedBehavior: 'Should read and return file contents',
    knownIssue: 'Path traversal vulnerability'
  },
  {
    title: 'Memory Leak in Event Listener',
    language: 'JavaScript',
    code: `class DataProcessor {
  constructor() {
    this.data = [];
  }

  start() {
    setInterval(() => {
      this.data.push(this.fetchNewData());
      if (this.data.length > 10000) {
        this.data.shift();
      }
    }, 1000);
  }

  fetchNewData() {
    return { timestamp: Date.now(), value: Math.random() };
  }
}`,
    expectedBehavior: 'Should process data periodically without memory issues',
    knownIssue: 'Data array grows indefinitely with large objects'
  },
  {
    title: 'Password Hashing Function',
    language: 'Python',
    code: `import hashlib

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

def verify_password(password, hash_value):
    return hash_password(password) == hash_value`,
    expectedBehavior: 'Should securely hash and verify passwords',
    knownIssue: 'MD5 is cryptographically broken'
  },
  {
    title: 'Recursive Fibonacci',
    language: 'JavaScript',
    code: `function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

// Calculate the 40th Fibonacci number
const result = fibonacci(40);
console.log(result);`,
    expectedBehavior: 'Should calculate Fibonacci numbers efficiently',
    knownIssue: 'Exponential time complexity without memoization'
  },
  {
    title: 'API Rate Limiter',
    language: 'Python',
    code: `class RateLimiter:
    def __init__(self, max_requests=100, window_seconds=60):
        self.max_requests = max_requests
        self.window = window_seconds
        self.requests = {}

    def check(self, user_id):
        now = time.time()
        if user_id not in self.requests:
            self.requests[user_id] = []
        
        self.requests[user_id].append(now)
        return len(self.requests[user_id]) <= self.max_requests`,
    expectedBehavior: 'Should limit API requests per user within a time window',
    knownIssue: 'Old requests are never cleaned up from memory'
  },
  {
    title: 'React Component with Missing Cleanup',
    language: 'TypeScript',
    code: `import { useState, useEffect } from 'react';

function UserProfile({ userId }: { userId: string }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch(\`/api/users/\${userId}\`)
      .then(res => res.json())
      .then(setData);
  }, [userId]);

  if (!data) return <div>Loading...</div>;
  return <div>{data.name}</div>;
}`,
    expectedBehavior: 'Should fetch and display user profile data',
    knownIssue: 'No cleanup for race conditions when userId changes rapidly'
  },
  {
    title: 'Authentication Middleware',
    language: 'TypeScript',
    code: `function authenticate(req, res, next) {
  const token = req.headers.authorization;
  
  if (!token) {
    return res.status(401).json({ error: 'No token' });
  }
  
  try {
    const decoded = jwt.verify(token, 'secret-key');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
}`,
    expectedBehavior: 'Should validate JWT tokens and protect routes',
    knownIssue: 'Hardcoded secret key, no token expiration check'
  },
  {
    title: 'Database Connection Pool',
    language: 'Java',
    code: `public class DatabaseManager {
    private static Connection connection;
    
    public static Connection getConnection() {
        if (connection == null) {
            connection = DriverManager.getConnection(URL, USER, PASS);
        }
        return connection;
    }
    
    public static void executeQuery(String query) {
        Statement stmt = getConnection().createStatement();
        ResultSet rs = stmt.executeQuery(query);
        // Process results
    }
}`,
    expectedBehavior: 'Should manage database connections efficiently',
    knownIssue: 'Not thread-safe, no connection pooling'
  },
  {
    title: 'Caching Implementation',
    language: 'JavaScript',
    code: `class Cache {
  constructor() {
    this.store = new Map();
  }

  set(key, value, ttl) {
    this.store.set(key, {
      value,
      expiry: Date.now() + ttl
    });
  }

  get(key) {
    const item = this.store.get(key);
    if (!item) return null;
    if (Date.now() > item.expiry) {
      this.store.delete(key);
      return null;
    }
    return item.value;
  }
}`,
    expectedBehavior: 'Should cache values with TTL and auto-expire',
    knownIssue: 'Expired items only cleaned on access, no automatic cleanup'
  },
  {
    title: 'Email Validator Regex',
    language: 'Python',
    code: `import re

def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9]+@[a-zA-Z0-9]+\\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

# Test cases
print(is_valid_email("user@example.com"))  # True
print(is_valid_email("user.name@example.com"))  # False (should be True)`,
    expectedBehavior: 'Should validate email addresses correctly',
    knownIssue: 'Regex is too restrictive for valid email formats'
  },
  {
    title: 'Retry Logic with Exponential Backoff',
    language: 'TypeScript',
    code: `async function fetchWithRetry(url, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url);
      return await response.json();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      await new Promise(resolve => 
        setTimeout(resolve, Math.pow(2, i) * 1000)
      );
    }
  }
}`,
    expectedBehavior: 'Should retry failed requests with exponential backoff',
    knownIssue: 'No jitter, no timeout, retries on non-retryable errors'
  },
  {
    title: 'Binary Search Implementation',
    language: 'Python',
    code: `def binary_search(arr, target):
    left, right = 0, len(arr)
    
    while left < right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid
    
    return -1`,
    expectedBehavior: 'Should find target element index in sorted array',
    knownIssue: 'Integer overflow possible with very large arrays (in other languages)'
  },
  {
    title: 'Express Error Handler',
    language: 'JavaScript',
    code: `app.use(async (err, req, res, next) => {
  console.error(err.stack);
  
  if (err instanceof ValidationError) {
    return res.status(400).json({ 
      error: err.message,
      stack: err.stack 
    });
  }
  
  res.status(500).json({ 
    error: 'Internal server error',
    details: err.message,
    stack: err.stack 
  });
});`,
    expectedBehavior: 'Should handle errors securely without exposing internals',
    knownIssue: 'Stack traces exposed to clients in production'
  },
  {
    title: 'Async Data Processor',
    language: 'Python',
    code: `async def process_items(items):
    results = []
    for item in items:
        result = await process_single(item)
        results.append(result)
    return results

async def process_single(item):
    # Simulate I/O operation
    await asyncio.sleep(0.1)
    return item * 2`,
    expectedBehavior: 'Should process items concurrently for better performance',
    knownIssue: 'Processes items sequentially instead of concurrently'
  },
  {
    title: 'Deep Clone Utility',
    language: 'JavaScript',
    code: `function deepClone(obj) {
  const clone = {};
  
  for (let key in obj) {
    if (typeof obj[key] === 'object' && obj[key] !== null) {
      clone[key] = deepClone(obj[key]);
    } else {
      clone[key] = obj[key];
    }
  }
  
  return clone;
}`,
    expectedBehavior: 'Should create deep copies of objects including arrays, dates, etc.',
    knownIssue: 'Does not handle arrays, dates, null, Map, Set, etc.'
  },
  {
    title: 'CORS Configuration',
    language: 'TypeScript',
    code: `app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));`,
    expectedBehavior: 'Should configure CORS properly for the API',
    knownIssue: 'credentials: true is incompatible with origin: "*"'
  },
  {
    title: 'Promise-based Queue',
    language: 'JavaScript',
    code: `class TaskQueue {
  constructor(concurrency = 1) {
    this.concurrency = concurrency;
    this.running = 0;
    this.queue = [];
  }

  push(task) {
    return new Promise((resolve, reject) => {
      this.queue.push({ task, resolve, reject });
      this.run();
    });
  }

  run() {
    while (this.running < this.concurrency && this.queue.length) {
      const { task, resolve, reject } = this.queue.shift();
      this.running++;
      task()
        .then(resolve)
        .catch(reject)
        .finally(() => {
          this.running--;
          this.run();
        });
    }
  }
}`,
    expectedBehavior: 'Should process tasks with limited concurrency',
    knownIssue: 'No error handling for task queue overflow'
  }
]

async function main() {
  console.log('Seeding database...')

  // Create snippets
  for (const snippet of sampleSnippets) {
    await db.codeSnippet.create({ data: snippet })
  }

  console.log(`Created ${sampleSnippets.length} code snippets`)

  // Get all snippets to create reviews for some of them
  const allSnippets = await db.codeSnippet.findMany()
  
  // Create some pre-existing reviews with feedback
  const sampleReviews = [
    {
      snippetId: allSnippets[0].id,
      summary: 'Critical security vulnerability: Use of eval() allows arbitrary code execution. This code is extremely dangerous in production.',
      feedback: JSON.stringify([
        {
          type: 'security',
          severity: 'critical',
          title: 'Arbitrary Code Execution via eval()',
          description: 'The eval() function executes arbitrary JavaScript code, allowing attackers to inject malicious code through user input.',
          line: 2,
          suggestion: 'Replace eval() with JSON.parse() for JSON data, or use a proper parser for other formats.',
          testCaseHint: 'Test with input: "alert(\'XSS\')" and verify it doesn\'t execute'
        },
        {
          type: 'best_practice',
          severity: 'medium',
          title: 'Missing Input Validation',
          description: 'No validation is performed on the input before processing.',
          line: 1,
          suggestion: 'Add input validation with a schema or type checking before processing.',
          testCaseHint: 'Test with null, undefined, and non-string inputs'
        }
      ]),
      score: 15
    },
    {
      snippetId: allSnippets[1].id,
      summary: 'Critical SQL injection vulnerability detected. User input is directly interpolated into SQL query.',
      feedback: JSON.stringify([
        {
          type: 'security',
          severity: 'critical',
          title: 'SQL Injection Vulnerability',
          description: 'User input is directly interpolated into the SQL query using f-strings, allowing SQL injection attacks.',
          line: 2,
          suggestion: 'Use parameterized queries: cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))',
          testCaseHint: 'Test with input: "1 OR 1=1" and verify it doesn\'t return all users'
        },
        {
          type: 'best_practice',
          severity: 'low',
          title: 'Missing Error Handling',
          description: 'No try-except block to handle database errors.',
          line: 1,
          suggestion: 'Wrap database operations in try-except blocks and handle connection errors gracefully.',
          testCaseHint: 'Test with non-existent user_id and database disconnection'
        }
      ]),
      score: 10
    },
    {
      snippetId: allSnippets[2].id,
      summary: 'The sort() method without a comparator sorts elements as strings, not numbers. This is a common JavaScript gotcha.',
      feedback: JSON.stringify([
        {
          type: 'bug',
          severity: 'high',
          title: 'Lexicographic Sort Instead of Numeric',
          description: 'Array.sort() without a comparator converts elements to strings and sorts lexicographically. [10, 2, 30, 1, 20] becomes [1, 10, 2, 20, 30].',
          line: 2,
          suggestion: 'Use arr.sort((a, b) => a - b) for numeric ascending sort.',
          testCaseHint: 'Test with [10, 2, 30, 1, 20] and verify result is [1, 2, 10, 20, 30]'
        }
      ]),
      score: 40
    },
    {
      snippetId: allSnippets[5].id,
      summary: 'MD5 is cryptographically broken and should not be used for password hashing. No salt is used either.',
      feedback: JSON.stringify([
        {
          type: 'security',
          severity: 'critical',
          title: 'MD5 is Cryptographically Broken',
          description: 'MD5 is vulnerable to collision attacks and is not suitable for password hashing. No salt is used, making rainbow table attacks trivial.',
          line: 4,
          suggestion: 'Use bcrypt, scrypt, or Argon2 with proper salting for password hashing.',
          testCaseHint: 'Test that identical passwords produce different hashes (due to salt)'
        },
        {
          type: 'best_practice',
          severity: 'high',
          title: 'No Salt in Password Hashing',
          description: 'Without salt, identical passwords produce identical hashes, enabling rainbow table attacks.',
          line: 4,
          suggestion: 'Use a library like bcrypt that handles salt generation automatically.',
          testCaseHint: 'Verify that hash_password("same") called twice returns different values'
        }
      ]),
      score: 8
    },
    {
      snippetId: allSnippets[6].id,
      summary: 'The recursive Fibonacci implementation has exponential time complexity O(2^n). It will be extremely slow for large values of n.',
      feedback: JSON.stringify([
        {
          type: 'performance',
          severity: 'high',
          title: 'Exponential Time Complexity',
          description: 'The recursive implementation recalculates the same values many times. fibonacci(40) requires over 1 billion recursive calls.',
          line: 3,
          suggestion: 'Use memoization, dynamic programming, or iterative approach for O(n) complexity.',
          testCaseHint: 'Measure execution time for n=40 with and without memoization'
        },
        {
          type: 'edge_case',
          severity: 'medium',
          title: 'No Input Validation for Negative Numbers',
          description: 'The function doesn\'t handle negative numbers, which would cause infinite recursion.',
          line: 2,
          suggestion: 'Add input validation: if (n < 0) throw new Error("n must be non-negative")',
          testCaseHint: 'Test with fibonacci(-1) and verify it throws an error'
        }
      ]),
      score: 35
    }
  ]

  for (const review of sampleReviews) {
    await db.review.create({ data: review })
  }

  console.log(`Created ${sampleReviews.length} sample reviews`)

  // Create some bug tickets
  const allReviews = await db.review.findMany()
  
  const sampleTickets = [
    {
      reviewId: allReviews[0].id,
      title: 'Fix eval() vulnerability in user input handler',
      description: 'The processUserInput function uses eval() which allows arbitrary code execution. Replace with JSON.parse() or a safe parser.',
      severity: 'critical',
      status: 'open',
      assignee: 'Security Team'
    },
    {
      reviewId: allReviews[1].id,
      title: 'Fix SQL injection in get_user function',
      description: 'The get_user function uses f-string interpolation in SQL queries, allowing SQL injection. Use parameterized queries.',
      severity: 'critical',
      status: 'in_progress',
      assignee: 'Backend Team'
    },
    {
      reviewId: allReviews[2].id,
      title: 'Fix numeric sort comparator',
      description: 'Array.sort() without comparator sorts lexicographically. Add numeric comparator (a, b) => a - b.',
      severity: 'high',
      status: 'open',
      assignee: ''
    },
    {
      reviewId: allReviews[3].id,
      title: 'Replace MD5 with bcrypt for password hashing',
      description: 'MD5 is cryptographically broken and unsalted. Replace with bcrypt or Argon2.',
      severity: 'critical',
      status: 'resolved',
      assignee: 'Auth Team'
    },
    {
      reviewId: allReviews[4].id,
      title: 'Optimize Fibonacci with memoization',
      description: 'Recursive Fibonacci has O(2^n) complexity. Add memoization or convert to iterative approach.',
      severity: 'high',
      status: 'open',
      assignee: 'Performance Team'
    }
  ]

  for (const ticket of sampleTickets) {
    await db.bugTicket.create({ data: ticket })
  }

  console.log(`Created ${sampleTickets.length} sample tickets`)
  console.log('Seeding complete!')
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())
