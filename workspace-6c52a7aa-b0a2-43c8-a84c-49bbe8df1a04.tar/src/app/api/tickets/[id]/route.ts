import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { severity, status, assignee, title, description } = body

    const existing = await db.bugTicket.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    const ticket = await db.bugTicket.update({
      where: { id },
      data: {
        ...(severity !== undefined && { severity }),
        ...(status !== undefined && { status }),
        ...(assignee !== undefined && { assignee }),
        ...(title !== undefined && { title }),
        ...(description !== undefined && { description })
      },
      include: {
        review: {
          select: {
            id: true,
            summary: true,
            snippet: { select: { id: true, title: true, language: true } }
          }
        }
      }
    })

    return NextResponse.json({ ticket })
  } catch (error) {
    console.error('Error updating ticket:', error)
    return NextResponse.json({ error: 'Failed to update ticket' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const existing = await db.bugTicket.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    await db.bugTicket.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting ticket:', error)
    return NextResponse.json({ error: 'Failed to delete ticket' }, { status: 500 })
  }
}
