import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const severity = searchParams.get('severity')
    const status = searchParams.get('status')
    const reviewId = searchParams.get('reviewId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')

    const where: Record<string, unknown> = {}
    if (severity) where.severity = severity
    if (status) where.status = status
    if (reviewId) where.reviewId = reviewId

    const [tickets, total] = await Promise.all([
      db.bugTicket.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          review: {
            select: {
              id: true,
              summary: true,
              snippet: { select: { id: true, title: true, language: true } }
            }
          }
        }
      }),
      db.bugTicket.count({ where })
    ])

    return NextResponse.json({
      tickets,
      total,
      page,
      totalPages: Math.ceil(total / limit)
    })
  } catch (error) {
    console.error('Error fetching tickets:', error)
    return NextResponse.json({ error: 'Failed to fetch tickets' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { reviewId, title, description, severity, assignee } = body

    if (!reviewId || !title || !description) {
      return NextResponse.json(
        { error: 'reviewId, title, and description are required' },
        { status: 400 }
      )
    }

    const ticket = await db.bugTicket.create({
      data: {
        reviewId,
        title,
        description,
        severity: severity || 'medium',
        assignee: assignee || ''
      },
      include: {
        review: {
          select: {
            id: true,
            summary: true,
            snippet: { select: { id: true, title: true, language: true } }
          }
        }
      }
    })

    return NextResponse.json({ ticket }, { status: 201 })
  } catch (error) {
    console.error('Error creating ticket:', error)
    return NextResponse.json({ error: 'Failed to create ticket' }, { status: 500 })
  }
}
