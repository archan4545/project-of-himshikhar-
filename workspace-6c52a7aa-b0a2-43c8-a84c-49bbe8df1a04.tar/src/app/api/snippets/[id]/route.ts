import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const snippet = await db.codeSnippet.findUnique({
      where: { id },
      include: {
        reviews: {
          orderBy: { createdAt: 'desc' },
          include: { tickets: true }
        }
      }
    })

    if (!snippet) {
      return NextResponse.json({ error: 'Snippet not found' }, { status: 404 })
    }

    return NextResponse.json({ snippet })
  } catch (error) {
    console.error('Error fetching snippet:', error)
    return NextResponse.json({ error: 'Failed to fetch snippet' }, { status: 500 })
  }
}
