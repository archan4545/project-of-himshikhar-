import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const language = searchParams.get('language')
    const search = searchParams.get('search')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    const where: Record<string, unknown> = {}
    if (language) where.language = language
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { code: { contains: search } }
      ]
    }

    const [snippets, total] = await Promise.all([
      db.codeSnippet.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          reviews: { select: { id: true, score: true, createdAt: true } }
        }
      }),
      db.codeSnippet.count({ where })
    ])

    return NextResponse.json({
      snippets,
      total,
      page,
      totalPages: Math.ceil(total / limit)
    })
  } catch (error) {
    console.error('Error fetching snippets:', error)
    return NextResponse.json({ error: 'Failed to fetch snippets' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, language, code, expectedBehavior, knownIssue } = body

    if (!title || !language || !code) {
      return NextResponse.json(
        { error: 'Title, language, and code are required' },
        { status: 400 }
      )
    }

    const snippet = await db.codeSnippet.create({
      data: {
        title,
        language,
        code,
        expectedBehavior: expectedBehavior || '',
        knownIssue: knownIssue || ''
      }
    })

    return NextResponse.json({ snippet }, { status: 201 })
  } catch (error) {
    console.error('Error creating snippet:', error)
    return NextResponse.json({ error: 'Failed to create snippet' }, { status: 500 })
  }
}
