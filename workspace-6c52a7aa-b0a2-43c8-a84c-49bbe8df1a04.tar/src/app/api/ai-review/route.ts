import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { performAIReview } from '@/lib/ai-review'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { snippetId } = body

    if (!snippetId) {
      return NextResponse.json({ error: 'snippetId is required' }, { status: 400 })
    }

    const snippet = await db.codeSnippet.findUnique({
      where: { id: snippetId }
    })

    if (!snippet) {
      return NextResponse.json({ error: 'Snippet not found' }, { status: 404 })
    }

    // Perform AI review
    const aiResult = await performAIReview(
      snippet.code,
      snippet.language,
      snippet.expectedBehavior,
      snippet.knownIssue
    )

    // Store the review in the database
    const review = await db.review.create({
      data: {
        snippetId: snippet.id,
        summary: aiResult.summary,
        feedback: JSON.stringify(aiResult.items),
        score: aiResult.score
      },
      include: {
        snippet: { select: { id: true, title: true, language: true } }
      }
    })

    return NextResponse.json({ review, aiResult }, { status: 201 })
  } catch (error) {
    console.error('Error performing AI review:', error)
    return NextResponse.json({ error: 'Failed to perform AI review' }, { status: 500 })
  }
}
