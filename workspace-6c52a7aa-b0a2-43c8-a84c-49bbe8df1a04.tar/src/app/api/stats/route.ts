import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const [
      totalSnippets,
      totalReviews,
      totalTickets,
      openTickets,
      criticalTickets,
      highTickets,
      mediumTickets,
      lowTickets,
      recentSnippets,
      recentReviews,
      recentTickets,
      avgScore,
      ticketsByStatus,
      snippetsByLanguage
    ] = await Promise.all([
      db.codeSnippet.count(),
      db.review.count(),
      db.bugTicket.count(),
      db.bugTicket.count({ where: { status: 'open' } }),
      db.bugTicket.count({ where: { severity: 'critical' } }),
      db.bugTicket.count({ where: { severity: 'high' } }),
      db.bugTicket.count({ where: { severity: 'medium' } }),
      db.bugTicket.count({ where: { severity: 'low' } }),
      db.codeSnippet.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: { reviews: { select: { id: true, score: true } } }
      }),
      db.review.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: {
          snippet: { select: { title: true, language: true } },
          tickets: { select: { id: true } }
        }
      }),
      db.bugTicket.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: {
          review: {
            select: {
              snippet: { select: { title: true } }
            }
          }
        }
      }),
      db.review.aggregate({ _avg: { score: true } }),
      db.bugTicket.groupBy({
        by: ['status'],
        _count: { status: true }
      }),
      db.codeSnippet.groupBy({
        by: ['language'],
        _count: { language: true }
      })
    ])

    return NextResponse.json({
      stats: {
        totalSnippets,
        totalReviews,
        totalTickets,
        openTickets,
        criticalTickets,
        highTickets,
        mediumTickets,
        lowTickets,
        avgScore: avgScore._avg.score ? Math.round(avgScore._avg.score) : 0
      },
      recentSnippets,
      recentReviews,
      recentTickets,
      ticketsByStatus: ticketsByStatus.map(t => ({
        status: t.status,
        count: t._count.status
      })),
      snippetsByLanguage: snippetsByLanguage.map(s => ({
        language: s.language,
        count: s._count.language
      }))
    })
  } catch (error) {
    console.error('Error fetching stats:', error)
    return NextResponse.json({ error: 'Failed to fetch stats' }, { status: 500 })
  }
}
