'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism'
import ReactMarkdown from 'react-markdown'
import { format } from 'date-fns'
import { create } from 'zustand'

// Icons
import {
  Code2, ClipboardCheck, Bug, LayoutDashboard, Plus, Send, Search,
  Filter, ChevronDown, ChevronUp, Trash2, ExternalLink, Loader2,
  AlertTriangle, CheckCircle2, XCircle, Info, Zap, Shield, Palette,
  Gauge, FileCode2, Ticket, Activity, Eye, X, ArrowRight, List,
  LayoutGrid, RefreshCw
} from 'lucide-react'

// shadcn/ui components
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Progress } from '@/components/ui/progress'

// ─── Types ───────────────────────────────────────────────────────────────────

interface CodeSnippet {
  id: string
  title: string
  language: string
  code: string
  expectedBehavior: string
  knownIssue: string
  createdAt: string
  reviews?: Review[]
}

interface ReviewFeedbackItem {
  type: 'bug' | 'edge_case' | 'best_practice' | 'performance' | 'security' | 'style'
  severity: 'critical' | 'high' | 'medium' | 'low'
  title: string
  description: string
  line?: number
  suggestion: string
  testCaseHint?: string
}

interface Review {
  id: string
  snippetId: string
  summary: string
  feedback: string
  score: number
  createdAt: string
  snippet?: { id: string; title: string; language: string }
  tickets?: BugTicket[]
}

interface BugTicket {
  id: string
  reviewId: string
  title: string
  description: string
  severity: string
  status: string
  assignee: string
  createdAt: string
  review?: { id: string; summary: string; snippet?: { title: string; language: string } }
}

interface DashboardStats {
  totalSnippets: number
  totalReviews: number
  totalTickets: number
  openTickets: number
  criticalTickets: number
  highTickets: number
  mediumTickets: number
  lowTickets: number
  avgScore: number
}

// ─── Zustand Store ───────────────────────────────────────────────────────────

interface AppState {
  activeTab: string
  setActiveTab: (tab: string) => void
}

const useAppStore = create<AppState>((set) => ({
  activeTab: 'dashboard',
  setActiveTab: (tab) => set({ activeTab: tab }),
}))

// ─── Constants ───────────────────────────────────────────────────────────────

const LANGUAGES = ['JavaScript', 'Python', 'TypeScript', 'Java', 'Go', 'Rust', 'C++', 'C#', 'Ruby', 'PHP']

const SEVERITY_COLORS: Record<string, string> = {
  critical: 'bg-red-500 text-white',
  high: 'bg-orange-500 text-white',
  medium: 'bg-yellow-500 text-white',
  low: 'bg-green-500 text-white',
}

const SEVERITY_BORDER_COLORS: Record<string, string> = {
  critical: 'border-l-red-500',
  high: 'border-l-orange-500',
  medium: 'border-l-yellow-500',
  low: 'border-l-green-500',
}

const TYPE_ICONS: Record<string, React.ReactNode> = {
  bug: <Bug className="size-4 text-red-500" />,
  edge_case: <AlertTriangle className="size-4 text-orange-500" />,
  best_practice: <CheckCircle2 className="size-4 text-emerald-500" />,
  performance: <Gauge className="size-4 text-purple-500" />,
  security: <Shield className="size-4 text-red-600" />,
  style: <Palette className="size-4 text-teal-500" />,
}

const TYPE_BADGE_COLORS: Record<string, string> = {
  bug: 'bg-red-100 text-red-700 border-red-200',
  edge_case: 'bg-orange-100 text-orange-700 border-orange-200',
  best_practice: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  performance: 'bg-purple-100 text-purple-700 border-purple-200',
  security: 'bg-red-100 text-red-800 border-red-300',
  style: 'bg-teal-100 text-teal-700 border-teal-200',
}

const STATUS_COLUMNS = ['open', 'in_progress', 'resolved', 'closed']

const STATUS_LABELS: Record<string, string> = {
  open: 'Open',
  in_progress: 'In Progress',
  resolved: 'Resolved',
  closed: 'Closed',
}

const STATUS_COLORS: Record<string, string> = {
  open: 'bg-slate-100 border-slate-300',
  in_progress: 'bg-blue-50 border-blue-300',
  resolved: 'bg-emerald-50 border-emerald-300',
  closed: 'bg-gray-100 border-gray-300',
}

const STATUS_DOT_COLORS: Record<string, string> = {
  open: 'bg-slate-500',
  in_progress: 'bg-blue-500',
  resolved: 'bg-emerald-500',
  closed: 'bg-gray-400',
}

const PIE_COLORS = ['#10b981', '#14b8a6', '#06b6d4', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#6366f1', '#84cc16', '#f97316']

const languageMap: Record<string, string> = {
  JavaScript: 'javascript',
  Python: 'python',
  TypeScript: 'typescript',
  Java: 'java',
  Go: 'go',
  Rust: 'rust',
  'C++': 'cpp',
  'C#': 'csharp',
  Ruby: 'ruby',
  PHP: 'php',
}

// ─── API Helpers ─────────────────────────────────────────────────────────────

async function fetchAPI<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(error.error || `Request failed with status ${res.status}`)
  }
  return res.json()
}

// ─── Helper Components ───────────────────────────────────────────────────────

function ScoreBadge({ score }: { score: number }) {
  const color = score > 70 ? 'text-emerald-600' : score >= 40 ? 'text-orange-500' : 'text-red-600'
  const bg = score > 70 ? 'bg-emerald-50' : score >= 40 ? 'bg-orange-50' : 'bg-red-50'
  return (
    <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-sm font-bold ${bg} ${color}`}>
      {score}/100
    </span>
  )
}

function SeverityBadge({ severity }: { severity: string }) {
  return (
    <Badge className={`${SEVERITY_COLORS[severity] || 'bg-gray-500 text-white'} border-0 text-xs`}>
      {severity}
    </Badge>
  )
}

function TypeBadge({ type }: { type: string }) {
  return (
    <Badge variant="outline" className={`${TYPE_BADGE_COLORS[type] || 'bg-gray-100 text-gray-700'} text-xs gap-1`}>
      {TYPE_ICONS[type]}
      {type.replace('_', ' ')}
    </Badge>
  )
}

function LanguageBadge({ language }: { language: string }) {
  return (
    <Badge variant="secondary" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">
      <FileCode2 className="size-3" />
      {language}
    </Badge>
  )
}

function StatusBadge({ status }: { status: string }) {
  const dot = STATUS_DOT_COLORS[status] || 'bg-gray-400'
  return (
    <Badge variant="outline" className="text-xs gap-1">
      <span className={`size-2 rounded-full ${dot}`} />
      {STATUS_LABELS[status] || status}
    </Badge>
  )
}

function EmptyState({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="rounded-full bg-muted p-4 mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-muted-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground mt-1 max-w-sm">{description}</p>
    </div>
  )
}

function LoadingCard() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-4 w-24 mt-2" />
      </CardHeader>
      <CardContent>
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4 mt-2" />
      </CardContent>
    </Card>
  )
}

// ─── Dashboard Tab ───────────────────────────────────────────────────────────

function DashboardTab() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [recentSnippets, setRecentSnippets] = useState<CodeSnippet[]>([])
  const [recentReviews, setRecentReviews] = useState<Review[]>([])
  const [recentTickets, setRecentTickets] = useState<BugTicket[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const loadDashboard = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await fetchAPI<{
        stats: DashboardStats
        recentSnippets: CodeSnippet[]
        recentReviews: Review[]
        recentTickets: BugTicket[]
        ticketsByStatus: { status: string; count: number }[]
        snippetsByLanguage: { language: string; count: number }[]
      }>('/api/stats')
      setStats(data.stats)
      setRecentSnippets(data.recentSnippets)
      setRecentReviews(data.recentReviews)
      setRecentTickets(data.recentTickets)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadDashboard() }, [loadDashboard])

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <LoadingCard key={i} />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <LoadingCard />
          <LoadingCard />
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <Card className="border-red-200">
        <CardContent className="p-6 text-center">
          <XCircle className="size-10 text-red-500 mx-auto mb-3" />
          <p className="text-red-600 font-medium">{error}</p>
          <Button variant="outline" onClick={loadDashboard} className="mt-4">
            <RefreshCw className="size-4 mr-2" /> Retry
          </Button>
        </CardContent>
      </Card>
    )
  }

  const severityChartData = stats ? [
    { name: 'Critical', count: stats.criticalTickets, fill: '#ef4444' },
    { name: 'High', count: stats.highTickets, fill: '#f97316' },
    { name: 'Medium', count: stats.mediumTickets, fill: '#eab308' },
    { name: 'Low', count: stats.lowTickets, fill: '#22c55e' },
  ] : []

  // Use snippetsByLanguage from stats or derive from recent snippets
  const languageCounts: Record<string, number> = {}
  recentSnippets.forEach(s => {
    languageCounts[s.language] = (languageCounts[s.language] || 0) + 1
  })
  const languageChartData = Object.entries(languageCounts).map(([lang, count], idx) => ({
    name: lang,
    value: count,
    fill: PIE_COLORS[idx % PIE_COLORS.length],
  }))

  const statCards = stats ? [
    { title: 'Total Snippets', value: stats.totalSnippets, icon: <FileCode2 className="size-5" />, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { title: 'Total Reviews', value: stats.totalReviews, icon: <ClipboardCheck className="size-5" />, color: 'text-teal-600', bg: 'bg-teal-50' },
    { title: 'Open Tickets', value: stats.openTickets, icon: <Ticket className="size-5" />, color: 'text-orange-600', bg: 'bg-orange-50' },
    { title: 'Avg Quality Score', value: stats.avgScore, icon: <Gauge className="size-5" />, color: stats.avgScore > 70 ? 'text-emerald-600' : stats.avgScore >= 40 ? 'text-orange-500' : 'text-red-600', bg: stats.avgScore > 70 ? 'bg-emerald-50' : stats.avgScore >= 40 ? 'bg-orange-50' : 'bg-red-50' },
  ] : []

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <motion.div key={card.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                    <p className="text-3xl font-bold mt-1">{card.value}</p>
                  </div>
                  <div className={`rounded-full p-3 ${card.bg} ${card.color}`}>
                    {card.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Tickets by Severity</CardTitle>
              <CardDescription>Distribution of bug tickets by severity level</CardDescription>
            </CardHeader>
            <CardContent>
              {severityChartData.some(d => d.count > 0) ? (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={severityChartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{ borderRadius: '8px', border: '1px solid #e5e7eb' }}
                      formatter={(value: number) => [value, 'Count']}
                    />
                    <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                      {severityChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-[260px] text-muted-foreground text-sm">
                  No tickets yet
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Snippets by Language</CardTitle>
              <CardDescription>Distribution of code snippets by programming language</CardDescription>
            </CardHeader>
            <CardContent>
              {languageChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie
                      data={languageChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={3}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {languageChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => [value, 'Snippets']} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-[260px] text-muted-foreground text-sm">
                  No snippets yet
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Recent Snippets */}
              <div>
                <h4 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                  <FileCode2 className="size-4 text-emerald-600" /> Recent Snippets
                </h4>
                <div className="space-y-3 max-h-80 overflow-y-auto pr-2 custom-scrollbar">
                  {recentSnippets.length > 0 ? recentSnippets.map(snippet => (
                    <div key={snippet.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{snippet.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <LanguageBadge language={snippet.language} />
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(snippet.createdAt), 'MMM d')}
                          </span>
                        </div>
                      </div>
                    </div>
                  )) : (
                    <p className="text-xs text-muted-foreground py-4 text-center">No snippets yet</p>
                  )}
                </div>
              </div>

              {/* Recent Reviews */}
              <div>
                <h4 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                  <ClipboardCheck className="size-4 text-teal-600" /> Recent Reviews
                </h4>
                <div className="space-y-3 max-h-80 overflow-y-auto pr-2 custom-scrollbar">
                  {recentReviews.length > 0 ? recentReviews.map(review => (
                    <div key={review.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{review.snippet?.title || 'Review'}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <ScoreBadge score={review.score} />
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(review.createdAt), 'MMM d')}
                          </span>
                        </div>
                      </div>
                    </div>
                  )) : (
                    <p className="text-xs text-muted-foreground py-4 text-center">No reviews yet</p>
                  )}
                </div>
              </div>

              {/* Recent Tickets */}
              <div>
                <h4 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                  <Ticket className="size-4 text-orange-600" /> Recent Tickets
                </h4>
                <div className="space-y-3 max-h-80 overflow-y-auto pr-2 custom-scrollbar">
                  {recentTickets.length > 0 ? recentTickets.map(ticket => (
                    <div key={ticket.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{ticket.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <SeverityBadge severity={ticket.severity} />
                          <StatusBadge status={ticket.status} />
                        </div>
                      </div>
                    </div>
                  )) : (
                    <p className="text-xs text-muted-foreground py-4 text-center">No tickets yet</p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}

// ─── Submit Code Tab ─────────────────────────────────────────────────────────

function SubmitCodeTab() {
  const [title, setTitle] = useState('')
  const [language, setLanguage] = useState('')
  const [code, setCode] = useState('')
  const [expectedBehavior, setExpectedBehavior] = useState('')
  const [knownIssue, setKnownIssue] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [createdSnippet, setCreatedSnippet] = useState<CodeSnippet | null>(null)
  const [aiReviewing, setAiReviewing] = useState(false)
  const [reviewResult, setReviewResult] = useState<Review | null>(null)
  const [feedbackItems, setFeedbackItems] = useState<ReviewFeedbackItem[]>([])
  const [error, setError] = useState<string | null>(null)
  const { setActiveTab } = useAppStore()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title || !language || !code) return

    setSubmitting(true)
    setError(null)
    setReviewResult(null)
    setFeedbackItems([])

    try {
      const data = await fetchAPI<{ snippet: CodeSnippet }>('/api/snippets', {
        method: 'POST',
        body: JSON.stringify({ title, language, code, expectedBehavior, knownIssue }),
      })
      setCreatedSnippet(data.snippet)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit snippet')
    } finally {
      setSubmitting(false)
    }
  }

  const handleAIReview = async () => {
    if (!createdSnippet) return
    setAiReviewing(true)
    setError(null)

    try {
      const data = await fetchAPI<{ review: Review }>('/api/ai-review', {
        method: 'POST',
        body: JSON.stringify({ snippetId: createdSnippet.id }),
      })
      setReviewResult(data.review)
      const parsed = JSON.parse(data.review.feedback)
      setFeedbackItems(Array.isArray(parsed) ? parsed : [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to run AI review')
    } finally {
      setAiReviewing(false)
    }
  }

  const handleReset = () => {
    setTitle('')
    setLanguage('')
    setCode('')
    setExpectedBehavior('')
    setKnownIssue('')
    setCreatedSnippet(null)
    setReviewResult(null)
    setFeedbackItems([])
    setError(null)
  }

  if (createdSnippet && !reviewResult) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="size-5 text-emerald-600" />
              Snippet Created Successfully
            </CardTitle>
            <CardDescription>Your code has been submitted and is ready for AI review</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-sm font-medium">Title</Label>
              <p className="text-sm mt-1">{createdSnippet.title}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Language</Label>
              <div className="mt-1"><LanguageBadge language={createdSnippet.language} /></div>
            </div>
            <div>
              <Label className="text-sm font-medium">Code</Label>
              <div className="mt-1 rounded-lg overflow-hidden">
                <SyntaxHighlighter
                  language={languageMap[createdSnippet.language] || 'text'}
                  style={vscDarkPlus}
                  customStyle={{ margin: 0, borderRadius: '8px', fontSize: '13px' }}
                  showLineNumbers
                >
                  {createdSnippet.code}
                </SyntaxHighlighter>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex gap-3">
            <Button onClick={handleAIReview} disabled={aiReviewing} className="bg-emerald-600 hover:bg-emerald-700">
              {aiReviewing ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Analyzing Code...
                </>
              ) : (
                <>
                  <Zap className="size-4 mr-2" />
                  Run AI Review
                </>
              )}
            </Button>
            <Button variant="outline" onClick={handleReset}>Submit Another</Button>
          </CardFooter>
        </Card>

        {error && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4">
              <p className="text-red-600 text-sm flex items-center gap-2">
                <XCircle className="size-4" /> {error}
              </p>
            </CardContent>
          </Card>
        )}

        {aiReviewing && (
          <Card>
            <CardContent className="p-8 text-center">
              <Loader2 className="size-8 text-emerald-600 animate-spin mx-auto mb-3" />
              <p className="font-medium">AI is analyzing your code...</p>
              <p className="text-sm text-muted-foreground mt-1">This may take a few seconds</p>
            </CardContent>
          </Card>
        )}
      </div>
    )
  }

  if (reviewResult && createdSnippet) {
    const isPerfect = reviewResult.score === 100
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        <Card className={isPerfect ? 'border-emerald-400 ring-2 ring-emerald-200' : ''}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                {isPerfect ? (
                  <CheckCircle2 className="size-5 text-emerald-600" />
                ) : (
                  <ClipboardCheck className="size-5 text-emerald-600" />
                )}
                {isPerfect ? 'Perfect Score! 🎉' : 'AI Review Complete'}
              </CardTitle>
              <ScoreBadge score={reviewResult.score} />
            </div>
            <CardDescription>{reviewResult.summary}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Quality Score Bar */}
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium">Quality Score</span>
                <span className={reviewResult.score > 70 ? 'text-emerald-600' : reviewResult.score >= 40 ? 'text-orange-500' : 'text-red-600'}>
                  {reviewResult.score}%
                </span>
              </div>
              <Progress
                value={reviewResult.score}
                className={`h-2 ${reviewResult.score === 100 ? '[&>div]:bg-emerald-500' : ''}`}
              />
            </div>

            {/* Feedback Items */}
            {feedbackItems.length === 0 ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 text-center">
                <CheckCircle2 className="size-10 text-emerald-500 mx-auto mb-3" />
                <h4 className="text-lg font-semibold text-emerald-800 mb-1">No Issues Found!</h4>
                <p className="text-sm text-emerald-600">This code is clean — no bugs, errors, or security vulnerabilities detected. Great work! 🎉</p>
              </div>
            ) : (
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <AlertTriangle className="size-4" />
                  Issues Found ({feedbackItems.length})
                </h4>
                <Accordion type="multiple" className="space-y-2">
                  {feedbackItems.map((item, idx) => (
                    <AccordionItem key={idx} value={`item-${idx}`} className={`border-l-4 ${SEVERITY_BORDER_COLORS[item.severity]} rounded-lg px-4`}>
                      <AccordionTrigger className="hover:no-underline py-3">
                        <div className="flex items-center gap-2 flex-wrap">
                          <TypeBadge type={item.type} />
                          <SeverityBadge severity={item.severity} />
                          <span className="text-sm font-medium text-left">{item.title}</span>
                          {item.line && (
                            <Badge variant="outline" className="text-xs">Line {item.line}</Badge>
                          )}
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pb-4 space-y-3">
                        <div>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                        <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
                          <p className="text-sm font-medium text-emerald-800 flex items-center gap-1 mb-1">
                            <CheckCircle2 className="size-4" /> Suggestion
                          </p>
                          <p className="text-sm text-emerald-700">{item.suggestion}</p>
                        </div>
                        {item.testCaseHint && (
                          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                            <p className="text-sm font-medium text-amber-800 flex items-center gap-1 mb-1">
                              <Info className="size-4" /> Test Case Hint
                            </p>
                            <p className="text-sm text-amber-700">{item.testCaseHint}</p>
                          </div>
                        )}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            )}

            {/* Original Code */}
            <div>
              <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                <FileCode2 className="size-4" /> Original Code
              </h4>
              <div className="rounded-lg overflow-hidden">
                <SyntaxHighlighter
                  language={languageMap[createdSnippet.language] || 'text'}
                  style={vscDarkPlus}
                  customStyle={{ margin: 0, borderRadius: '8px', fontSize: '13px', maxHeight: '400px' }}
                  showLineNumbers
                >
                  {createdSnippet.code}
                </SyntaxHighlighter>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex gap-3">
            <Button onClick={() => setActiveTab('reviews')} variant="outline">
              View All Reviews <ArrowRight className="size-4 ml-1" />
            </Button>
            <Button onClick={handleReset} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="size-4 mr-1" /> Submit New Code
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code2 className="size-5 text-emerald-600" />
            Submit Code for Review
          </CardTitle>
          <CardDescription>Paste your code and let AI analyze it for bugs, performance issues, and best practices</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                placeholder="e.g., User authentication middleware"
                value={title}
                onChange={e => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="language">Language *</Label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a language" />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map(lang => (
                    <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="code">Code *</Label>
              <Textarea
                id="code"
                placeholder="Paste your code here..."
                value={code}
                onChange={e => setCode(e.target.value)}
                required
                className="min-h-[250px] font-mono text-sm bg-gray-950 text-green-400 border-gray-800 focus-visible:ring-emerald-500 placeholder:text-gray-600"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expectedBehavior">Expected Behavior</Label>
              <Textarea
                id="expectedBehavior"
                placeholder="What should this code do?"
                value={expectedBehavior}
                onChange={e => setExpectedBehavior(e.target.value)}
                className="min-h-[80px]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="knownIssue">Known Issues (Optional)</Label>
              <Textarea
                id="knownIssue"
                placeholder="Any known issues or concerns?"
                value={knownIssue}
                onChange={e => setKnownIssue(e.target.value)}
                className="min-h-[60px]"
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-red-600 text-sm flex items-center gap-2">
                  <XCircle className="size-4" /> {error}
                </p>
              </div>
            )}

            <Button type="submit" disabled={submitting || !title || !language || !code} className="w-full bg-emerald-600 hover:bg-emerald-700">
              {submitting ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="size-4 mr-2" />
                  Submit Code
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Reviews Tab ─────────────────────────────────────────────────────────────

function ReviewsTab() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [languageFilter, setLanguageFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedReview, setSelectedReview] = useState<Review | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [feedbackItems, setFeedbackItems] = useState<ReviewFeedbackItem[]>([])
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [creatingTicket, setCreatingTicket] = useState<string | null>(null)

  const loadReviews = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (languageFilter && languageFilter !== 'all') params.set('language', languageFilter)
      if (searchQuery) params.set('search', searchQuery)
      const data = await fetchAPI<{ reviews: Review[] }>(`/api/reviews?${params.toString()}`)
      setReviews(data.reviews)
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [languageFilter, searchQuery])

  useEffect(() => { loadReviews() }, [loadReviews])

  const openReviewDetail = async (review: Review) => {
    setDetailDialogOpen(true)
    setDetailLoading(true)
    try {
      const data = await fetchAPI<{ review: Review }>(`/api/reviews/${review.id}`)
      setSelectedReview(data.review)
      const parsed = JSON.parse(data.review.feedback)
      setFeedbackItems(Array.isArray(parsed) ? parsed : [])
    } catch {
      setSelectedReview(review)
      try {
        const parsed = JSON.parse(review.feedback)
        setFeedbackItems(Array.isArray(parsed) ? parsed : [])
      } catch {
        setFeedbackItems([])
      }
    } finally {
      setDetailLoading(false)
    }
  }

  const handleCreateTicket = async (item: ReviewFeedbackItem, reviewId: string) => {
    setCreatingTicket(item.title)
    try {
      await fetchAPI('/api/tickets', {
        method: 'POST',
        body: JSON.stringify({
          reviewId,
          title: item.title,
          description: `${item.description}\n\nSuggestion: ${item.suggestion}${item.testCaseHint ? `\n\nTest Case Hint: ${item.testCaseHint}` : ''}`,
          severity: item.severity,
        }),
      })
      setCreatingTicket(null)
      // Refresh reviews
      loadReviews()
    } catch {
      setCreatingTicket(null)
    }
  }

  const filteredReviews = reviews.filter(r => {
    if (languageFilter !== 'all' && r.snippet?.language !== languageFilter) return false
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      return (
        r.snippet?.title?.toLowerCase().includes(q) ||
        r.summary?.toLowerCase().includes(q)
      )
    }
    return true
  })

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Search reviews..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={languageFilter} onValueChange={setLanguageFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="size-4 mr-2" />
                <SelectValue placeholder="Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Languages</SelectItem>
                {LANGUAGES.map(lang => (
                  <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Reviews List */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map(i => <LoadingCard key={i} />)}
        </div>
      ) : filteredReviews.length === 0 ? (
        <EmptyState
          icon={<ClipboardCheck className="size-8 text-muted-foreground" />}
          title="No Reviews Yet"
          description="Submit code and run AI reviews to see them here"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredReviews.map((review, i) => (
            <motion.div key={review.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => openReviewDetail(review)}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base truncate">{review.snippet?.title || 'Review'}</CardTitle>
                      <div className="flex items-center gap-2 mt-2">
                        {review.snippet?.language && <LanguageBadge language={review.snippet.language} />}
                        <ScoreBadge score={review.score} />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-3">
                  <p className="text-sm text-muted-foreground line-clamp-2">{review.summary}</p>
                </CardContent>
                <CardFooter className="pt-0 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <AlertTriangle className="size-3" />
                      {(() => {
                        try {
                          const items = JSON.parse(review.feedback)
                          return Array.isArray(items) ? items.length : 0
                        } catch { return 0 }
                      })()} issues
                    </span>
                    <span className="flex items-center gap-1">
                      <Ticket className="size-3" />
                      {review.tickets?.length || 0} tickets
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" className="text-emerald-600 hover:text-emerald-700">
                    <Eye className="size-4 mr-1" /> Details
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Review Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          {detailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-8 text-emerald-600 animate-spin" />
            </div>
          ) : selectedReview ? (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3">
                  <DialogTitle>{selectedReview.snippet?.title || 'Review'}</DialogTitle>
                  <ScoreBadge score={selectedReview.score} />
                </div>
                <DialogDescription>{selectedReview.summary}</DialogDescription>
                {selectedReview.snippet?.language && (
                  <div className="mt-1"><LanguageBadge language={selectedReview.snippet.language} /></div>
                )}
              </DialogHeader>

              <Separator />

              {/* Feedback Items */}
              {feedbackItems.length === 0 ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 text-center">
                  <CheckCircle2 className="size-10 text-emerald-500 mx-auto mb-3" />
                  <h4 className="text-lg font-semibold text-emerald-800 mb-1">No Issues Found!</h4>
                  <p className="text-sm text-emerald-600">This code is clean — no bugs, errors, or security vulnerabilities detected. Great work! 🎉</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <AlertTriangle className="size-4" /> Issues Found ({feedbackItems.length})
                  </h4>
                  {feedbackItems.map((item, idx) => (
                    <Card key={idx} className={`border-l-4 ${SEVERITY_BORDER_COLORS[item.severity]}`}>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 flex-wrap mb-2">
                          <TypeBadge type={item.type} />
                          <SeverityBadge severity={item.severity} />
                          <span className="text-sm font-medium">{item.title}</span>
                          {item.line && (
                            <Badge variant="outline" className="text-xs">Line {item.line}</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{item.description}</p>
                        <div className="bg-emerald-50 border border-emerald-200 rounded-md p-2 mb-2">
                          <p className="text-xs font-medium text-emerald-800">Suggestion:</p>
                          <p className="text-xs text-emerald-700">{item.suggestion}</p>
                        </div>
                        {item.testCaseHint && (
                          <div className="bg-amber-50 border border-amber-200 rounded-md p-2 mb-2">
                            <p className="text-xs font-medium text-amber-800">Test Case Hint:</p>
                            <p className="text-xs text-amber-700">{item.testCaseHint}</p>
                          </div>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          className="mt-2 text-emerald-600 border-emerald-300 hover:bg-emerald-50"
                          disabled={creatingTicket === item.title}
                          onClick={() => handleCreateTicket(item, selectedReview.id)}
                        >
                          {creatingTicket === item.title ? (
                            <><Loader2 className="size-3 mr-1 animate-spin" /> Creating...</>
                          ) : (
                            <><Plus className="size-3 mr-1" /> Create Ticket</>
                          )}
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <Separator />

              {/* Code Display */}
              {selectedReview.snippet && (
                <div>
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <FileCode2 className="size-4" /> Original Code
                  </h4>
                  <div className="rounded-lg overflow-hidden">
                    <SyntaxHighlighter
                      language={languageMap[selectedReview.snippet.language] || 'text'}
                      style={vscDarkPlus}
                      customStyle={{ margin: 0, borderRadius: '8px', fontSize: '13px', maxHeight: '300px' }}
                      showLineNumbers
                    >
                      {selectedReview.snippet.code}
                    </SyntaxHighlighter>
                  </div>
                </div>
              )}

              {/* Tickets */}
              {selectedReview.tickets && selectedReview.tickets.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <Ticket className="size-4" /> Related Tickets ({selectedReview.tickets.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedReview.tickets.map(ticket => (
                        <div key={ticket.id} className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
                          <SeverityBadge severity={ticket.severity} />
                          <span className="text-sm flex-1 truncate">{ticket.title}</span>
                          <StatusBadge status={ticket.status} />
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ─── Bug Tracker Tab ─────────────────────────────────────────────────────────

function BugTrackerTab() {
  const [tickets, setTickets] = useState<BugTicket[]>([])
  const [loading, setLoading] = useState(true)
  const [severityFilter, setSeverityFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban')
  const [selectedTicket, setSelectedTicket] = useState<BugTicket | null>(null)
  const [ticketDialogOpen, setTicketDialogOpen] = useState(false)
  const [editStatus, setEditStatus] = useState('')
  const [editSeverity, setEditSeverity] = useState('')
  const [editAssignee, setEditAssignee] = useState('')
  const [saving, setSaving] = useState(false)

  const loadTickets = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (severityFilter !== 'all') params.set('severity', severityFilter)
      if (statusFilter !== 'all') params.set('status', statusFilter)
      const data = await fetchAPI<{ tickets: BugTicket[] }>(`/api/tickets?${params.toString()}`)
      setTickets(data.tickets)
    } catch {
      // silently fail
    } finally {
      setLoading(false)
    }
  }, [severityFilter, statusFilter])

  useEffect(() => { loadTickets() }, [loadTickets])

  const openTicketDetail = (ticket: BugTicket) => {
    setSelectedTicket(ticket)
    setEditStatus(ticket.status)
    setEditSeverity(ticket.severity)
    setEditAssignee(ticket.assignee)
    setTicketDialogOpen(true)
  }

  const handleUpdateTicket = async () => {
    if (!selectedTicket) return
    setSaving(true)
    try {
      const data = await fetchAPI<{ ticket: BugTicket }>(`/api/tickets/${selectedTicket.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: editStatus,
          severity: editSeverity,
          assignee: editAssignee,
        }),
      })
      setTickets(prev => prev.map(t => t.id === data.ticket.id ? data.ticket : t))
      setTicketDialogOpen(false)
    } catch {
      // silently fail
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteTicket = async () => {
    if (!selectedTicket) return
    setSaving(true)
    try {
      await fetchAPI(`/api/tickets/${selectedTicket.id}`, { method: 'DELETE' })
      setTickets(prev => prev.filter(t => t.id !== selectedTicket.id))
      setTicketDialogOpen(false)
    } catch {
      // silently fail
    } finally {
      setSaving(false)
    }
  }

  const getTicketsByStatus = (status: string) => tickets.filter(t => t.status === status)

  const kanbanColCounts: Record<string, number> = {}
  STATUS_COLUMNS.forEach(s => { kanbanColCounts[s] = getTicketsByStatus(s).length })

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-3 flex-1">
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-full sm:w-[160px]">
                  <AlertTriangle className="size-4 mr-2" />
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[160px]">
                  <Filter className="size-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-1 bg-muted rounded-lg p-1">
              <Button
                variant={viewMode === 'kanban' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('kanban')}
                className={viewMode === 'kanban' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              >
                <LayoutGrid className="size-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className={viewMode === 'list' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              >
                <List className="size-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Kanban View */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <LoadingCard key={i} />)}
        </div>
      ) : viewMode === 'kanban' ? (
        tickets.length === 0 ? (
          <EmptyState
            icon={<Bug className="size-8 text-muted-foreground" />}
            title="No Bug Tickets"
            description="Create tickets from AI review feedback to track bugs here"
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {STATUS_COLUMNS.map(status => (
              <div key={status} className="space-y-3">
                <div className={`flex items-center justify-between px-3 py-2 rounded-lg border ${STATUS_COLORS[status]}`}>
                  <div className="flex items-center gap-2">
                    <span className={`size-2.5 rounded-full ${STATUS_DOT_COLORS[status]}`} />
                    <span className="text-sm font-semibold">{STATUS_LABELS[status]}</span>
                  </div>
                  <Badge variant="secondary" className="text-xs">{kanbanColCounts[status]}</Badge>
                </div>
                <div className="space-y-2 max-h-[60vh] overflow-y-auto custom-scrollbar">
                  {getTicketsByStatus(status).map((ticket, i) => (
                    <motion.div
                      key={ticket.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <Card
                        className={`cursor-pointer hover:shadow-md transition-shadow border-l-4 ${SEVERITY_BORDER_COLORS[ticket.severity]}`}
                        onClick={() => openTicketDetail(ticket)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-start justify-between mb-2">
                            <p className="text-sm font-medium line-clamp-2 flex-1">{ticket.title}</p>
                            <SeverityBadge severity={ticket.severity} />
                          </div>
                          {ticket.assignee && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1 mb-1">
                              <span className="size-2 rounded-full bg-emerald-500" />
                              {ticket.assignee}
                            </p>
                          )}
                          {ticket.review?.snippet?.title && (
                            <p className="text-xs text-muted-foreground truncate flex items-center gap-1">
                              <FileCode2 className="size-3" />
                              {ticket.review.snippet.title}
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(ticket.createdAt), 'MMM d, yyyy')}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                  {getTicketsByStatus(status).length === 0 && (
                    <div className="text-center py-6 text-muted-foreground text-xs">
                      No tickets
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* List View */
        tickets.length === 0 ? (
          <EmptyState
            icon={<Bug className="size-8 text-muted-foreground" />}
            title="No Bug Tickets"
            description="Create tickets from AI review feedback to track bugs here"
          />
        ) : (
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {tickets.map((ticket, i) => (
                  <motion.div
                    key={ticket.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.03 }}
                    className="flex items-center gap-3 p-4 hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() => openTicketDetail(ticket)}
                  >
                    <SeverityBadge severity={ticket.severity} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{ticket.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        {ticket.review?.snippet?.title && (
                          <span className="text-xs text-muted-foreground truncate">
                            {ticket.review.snippet.title}
                          </span>
                        )}
                        {ticket.assignee && (
                          <span className="text-xs text-muted-foreground">· {ticket.assignee}</span>
                        )}
                      </div>
                    </div>
                    <StatusBadge status={ticket.status} />
                    <span className="text-xs text-muted-foreground hidden sm:inline">
                      {format(new Date(ticket.createdAt), 'MMM d')}
                    </span>
                    <ExternalLink className="size-4 text-muted-foreground" />
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      )}

      {/* Ticket Detail Dialog */}
      <Dialog open={ticketDialogOpen} onOpenChange={setTicketDialogOpen}>
        <DialogContent className="max-w-lg">
          {selectedTicket ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Bug className="size-5 text-emerald-600" />
                  {selectedTicket.title}
                </DialogTitle>
                <DialogDescription>Ticket Details</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Description</Label>
                  <div className="mt-1 p-3 bg-muted/50 rounded-lg text-sm">
                    <ReactMarkdown>{selectedTicket.description}</ReactMarkdown>
                  </div>
                </div>

                {selectedTicket.review?.snippet?.title && (
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Associated Snippet</Label>
                    <div className="mt-1 flex items-center gap-2">
                      <FileCode2 className="size-4 text-emerald-600" />
                      <span className="text-sm">{selectedTicket.review.snippet.title}</span>
                      {selectedTicket.review.snippet.language && (
                        <LanguageBadge language={selectedTicket.review.snippet.language} />
                      )}
                    </div>
                  </div>
                )}

                <Separator />

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select value={editStatus} onValueChange={setEditStatus}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Severity</Label>
                    <Select value={editSeverity} onValueChange={setEditSeverity}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Assignee</Label>
                  <Input
                    placeholder="Enter assignee name"
                    value={editAssignee}
                    onChange={e => setEditAssignee(e.target.value)}
                  />
                </div>

                <p className="text-xs text-muted-foreground">
                  Created {format(new Date(selectedTicket.createdAt), 'MMM d, yyyy h:mm a')}
                </p>
              </div>

              <DialogFooter className="flex justify-between sm:justify-between">
                <Button variant="destructive" size="sm" onClick={handleDeleteTicket} disabled={saving}>
                  <Trash2 className="size-4 mr-1" /> Delete
                </Button>
                <Button onClick={handleUpdateTicket} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700">
                  {saving ? <Loader2 className="size-4 mr-1 animate-spin" /> : <CheckCircle2 className="size-4 mr-1" />}
                  Save Changes
                </Button>
              </DialogFooter>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export default function Home() {
  const { activeTab, setActiveTab } = useAppStore()

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-gray-900 via-gray-800 to-emerald-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-emerald-600 p-2">
              <Code2 className="size-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight">CodeLens AI</h1>
              <p className="text-emerald-300 text-xs sm:text-sm">AI-Powered Code Review & Bug Tracker</p>
            </div>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="bg-white border-b shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-transparent h-auto p-0 gap-0">
              <TabsTrigger
                value="dashboard"
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 data-[state=active]:text-emerald-700 rounded-none px-4 py-3 text-sm font-medium gap-2"
              >
                <LayoutDashboard className="size-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </TabsTrigger>
              <TabsTrigger
                value="submit"
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 data-[state=active]:text-emerald-700 rounded-none px-4 py-3 text-sm font-medium gap-2"
              >
                <Plus className="size-4" />
                <span className="hidden sm:inline">Submit Code</span>
              </TabsTrigger>
              <TabsTrigger
                value="reviews"
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 data-[state=active]:text-emerald-700 rounded-none px-4 py-3 text-sm font-medium gap-2"
              >
                <ClipboardCheck className="size-4" />
                <span className="hidden sm:inline">Reviews</span>
              </TabsTrigger>
              <TabsTrigger
                value="tracker"
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 data-[state=active]:text-emerald-700 rounded-none px-4 py-3 text-sm font-medium gap-2"
              >
                <Bug className="size-4" />
                <span className="hidden sm:inline">Bug Tracker</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="mt-6 mb-6">
              <DashboardTab />
            </TabsContent>
            <TabsContent value="submit" className="mt-6 mb-6">
              <SubmitCodeTab />
            </TabsContent>
            <TabsContent value="reviews" className="mt-6 mb-6">
              <ReviewsTab />
            </TabsContent>
            <TabsContent value="tracker" className="mt-6 mb-6">
              <BugTrackerTab />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 py-6 w-full">
        {/* Content is rendered by TabsContent above, this main is for layout flex only */}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-sm text-muted-foreground">
            <p className="flex items-center gap-2">
              <Code2 className="size-4 text-emerald-600" />
              CodeLens AI &copy; {new Date().getFullYear()}
            </p>
            <p>AI-Powered Code Review & Bug Tracker</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
