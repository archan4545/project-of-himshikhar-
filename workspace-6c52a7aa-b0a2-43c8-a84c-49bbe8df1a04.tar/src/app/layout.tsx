import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CodeLens AI - AI-Powered Code Review & Bug Tracker",
  description: "Submit code for AI-powered review. Identify bugs, edge cases, security vulnerabilities, and performance issues. Convert feedback into trackable bug tickets.",
  keywords: ["code review", "AI", "bug tracker", "code quality", "static analysis", "developer tools"],
  authors: [{ name: "CodeLens AI" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "CodeLens AI",
    description: "AI-Powered Code Review & Bug Tracker",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CodeLens AI",
    description: "AI-Powered Code Review & Bug Tracker",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
