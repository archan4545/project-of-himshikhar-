import ZAI from 'z-ai-web-dev-sdk'

export interface ReviewFeedbackItem {
  type: 'bug' | 'edge_case' | 'best_practice' | 'performance' | 'security' | 'style'
  severity: 'critical' | 'high' | 'medium' | 'low'
  title: string
  description: string
  line?: number
  suggestion: string
  testCaseHint?: string
}

export interface ReviewResult {
  summary: string
  score: number
  items: ReviewFeedbackItem[]
}

let zaiInstance: InstanceType<typeof ZAI> | null = null

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

export async function performAIReview(
  code: string,
  language: string,
  expectedBehavior: string,
  knownIssue: string
): Promise<ReviewResult> {
  const zai = await getZAI()

  const systemPrompt = `You are an expert code reviewer. Analyze the given code and provide a thorough review. 
You must respond with ONLY valid JSON matching this exact structure (no markdown, no code fences):
{
  "summary": "A brief overall summary of the code quality and main findings",
  "score": <number 0-100 representing code quality>,
  "items": [
    {
      "type": "<one of: bug, edge_case, best_practice, performance, security, style>",
      "severity": "<one of: critical, high, medium, low>",
      "title": "Short title of the issue",
      "description": "Detailed explanation of the issue",
      "line": <line number or null>,
      "suggestion": "Suggested fix or improvement",
      "testCaseHint": "Suggested test case to catch this issue or null"
    }
  ]
}

Rules:
- If the code has NO bugs, errors, security vulnerabilities, or logical issues, you MUST give a score of 100 and return an empty "items" array: { "items": [] }
- If the code is bug-free and error-free, the score MUST be 100 — do NOT deduct points for style preferences or optional improvements
- Only add items to the "items" array if there are actual bugs, errors, security issues, or edge case failures
- For bugs and security issues, set severity to critical or high
- For style and best practice suggestions (only when issues exist), set severity to medium or low
- Provide concrete, actionable suggestions for each issue found
- Include test case hints for bugs and edge cases
- Score should reflect overall code quality:
  - 100 = No bugs, no errors, code works correctly and safely
  - 90-99 = Excellent code with only minor style/optimization suggestions
  - 70-89 = Good code with some issues
  - 50-69 = Average code with notable problems
  - Below 50 = Needs significant work
- Return ONLY the JSON, no other text`

  const userPrompt = `Review this ${language} code:

\`\`\`${language}
${code}
\`\`\`

Expected behavior: ${expectedBehavior || 'Not specified'}
Known issues: ${knownIssue || 'None reported'}

Provide a thorough code review. If this code has NO bugs, NO errors, NO security issues, and NO logical problems, return score 100 with an empty items array. Only report actual problems.`

  const completion = await zai.chat.completions.create({
    messages: [
      { role: 'assistant', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    thinking: { type: 'disabled' }
  })

  const responseText = completion.choices[0]?.message?.content || ''

  try {
    // Try to parse the response as JSON
    let cleaned = responseText.trim()
    // Remove markdown code fences if present
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '')
    }
    const parsed = JSON.parse(cleaned) as ReviewResult
    return parsed
  } catch {
    // If parsing fails, create a fallback result
    return {
      summary: responseText.slice(0, 500),
      score: 50,
      items: [
        {
          type: 'best_practice',
          severity: 'medium',
          title: 'AI Review Completed',
          description: responseText.slice(0, 1000),
          suggestion: 'See the full review description for details.',
          testCaseHint: null
        }
      ]
    }
  }
}
